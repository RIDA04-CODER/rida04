# Textes humoristiques neutres pour le site web

## Textes d'accueil
- "Chère Salma, j'ai besoin de ton expertise d'infirmière... et d'un certificat médical ! 🏥"
- "Quand les cours deviennent trop intenses, seul un certificat médical peut me sauver !"
- "Mission urgente : convaincre l'infirmière Salma de me délivrer le précieux sésame !"

## Textes pour les sections de mèmes
- "Quand je dois expliquer à Salma pourquoi j'ai besoin d'un certificat médical..."
- "Moi après avoir passé la nuit à réviser pour les examens"
- "Comment je me sens quand j'attends dans la salle d'attente..."
- "Quand Salma me demande quels sont mes symptômes"
- "Moi qui essaie de paraître malade alors que je veux juste éviter l'examen de maths"

## Phrases humoristiques
- "Salma, tu es la meilleure infirmière du campus, ton aide serait vraiment appréciée !"
- "Ton certificat médical serait comme une bouée de sauvetage dans mon océan de devoirs"
- "Avec ton expertise médicale et ton professionnalisme, tu peux sauver ma moyenne semestrielle !"

## Phrases de conclusion
- "S'il te plaît, Salma, aide un pauvre étudiant en détresse académique !"
- "Un certificat médical de toi vaut tous les points bonus du monde !"
- "Promis, je reviendrai te voir quand j'aurai vraiment besoin de soins médicaux !"
